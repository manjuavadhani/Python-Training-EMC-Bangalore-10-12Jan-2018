class logger:
    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        ret_value = self.func(*args)
        print("{} called with args: {} return: {} ".format(self.func.__name__,
                                                           args, ret_value))
        return ret_value


@logger
def compute(a, b):
    return a + b


print(compute(2, 3))
