import pickle


class LineReader:
    def __init__(self, file_name):
        self.file_name = file_name
        self.fh = open(file_name)
        self.line_no = 0

    def stream_reader(self):
        self.line_no += 1
        line = self.fh.readline()

        return "{:>6}  {}".format(self.line_no, line.rstrip())

    def __getstate__(self):  # seralizing
        temp = self.__dict__.copy()
        del temp['fh']
        return temp

    def __setstate__(self, state):  # un-serialize
        state['fh'] = open(state['file_name'])

        for line in range(state['line_no']):
            state['fh'].readline()

        self.__dict__.update(state)


if __name__ == '__main__':
    #lr = LineReader('/etc/passwd')

    #for item in range(5):
    #    print(lr.stream_reader())

    # pickle.dump(lr, open('lr.pickle', 'wb'))

    obj_lr = pickle.load(open('lr.pickle', 'rb'))

    for item in range(5):
        print(obj_lr.stream_reader())
