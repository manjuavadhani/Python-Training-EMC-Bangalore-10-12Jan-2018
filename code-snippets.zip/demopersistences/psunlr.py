from demopersistences.pslinereader import LineReader
import pickle

obj_lr = pickle.load(open('lr.pickle', 'rb'))

for item in range(5):
    print(obj_lr.stream_reader())
