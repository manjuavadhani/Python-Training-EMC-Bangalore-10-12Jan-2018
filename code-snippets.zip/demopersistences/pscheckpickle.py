import pickle
from pprint import pprint as pp


def do_serialize():
    data_set = dict(
        lang=['perl', 'py'],
        detail=dict(author=['wall', 'heo']),
        version=2.2
    )

    pickle.dump(data_set, open('content.pickle', 'wb'))


def un_serialize():
    content = pickle.load(open('content.pickle', 'rb'))
    pp(content)

# do_serialize()
un_serialize()