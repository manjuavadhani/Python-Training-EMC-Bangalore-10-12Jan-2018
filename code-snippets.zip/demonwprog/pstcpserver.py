import socketserver
from time import ctime


class CustomRequestHandler(socketserver.BaseRequestHandler):
    def handle(self):
        print("client :", self.client_address)
        ts = ctime().encode('ascii')  # unicode string into byte string
        self.request.send(ts)


class DateTimeService:
    def __init__(self, hostname, port):

        self.server = socketserver.TCPServer((hostname, port),
                                             CustomRequestHandler)

        self.server.serve_forever()


if __name__ == '__main__':
    DateTimeService('localhost', 8989)