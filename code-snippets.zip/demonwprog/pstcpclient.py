import socket

try:
    server_addr = 'localhost', 8989
    sock = socket.socket()
    sock.connect(server_addr)
    payload = sock.recv(1204)
    print(payload)
    print()
    print(payload.decode('ascii')) # byte str into unicode
finally:
    sock.close()