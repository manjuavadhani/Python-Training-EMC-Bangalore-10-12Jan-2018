import re
from fileinput import input, filename, filelineno


class GrepMe:
    def __init__(self, pattern, *args):
        self.pattern = pattern
        self.file_names = args
        self.__do_match()

    def __do_match(self):
        for line in input(self.file_names):
            if re.search(self.pattern, line, re.I):
                print("{}:{}:{}".format(filename(), filelineno(), line), end='')

# 1[0-9][0-9]| 2[0-4][0-9] | 25[0-4]
pattern = r'\b([1-9]|[1-9][0-9]|1\d{2}|2[0-4][0-9]|25[0-4])'
pattern += r'(\.([0-9]|[1-9]\d|1\d{2}|2[0-4]\d|25[0-4])){3}\b'
# pattern += r'([0-9]|[1-9]\d|1\d{2}|2[0-4]\d|25[0-4])\b'

GrepMe(pattern, 'resolv.conf')
#GrepMe(r'\b[789][0-9]{9}\b', 'contacts.csv.py')
