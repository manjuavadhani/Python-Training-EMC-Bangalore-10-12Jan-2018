import re

s = 'root,x:0:0;root,/bin/bash'
pattern = '[,:;]'

items = re.split(pattern, s)
#print(" ".join(items))
print(*items)