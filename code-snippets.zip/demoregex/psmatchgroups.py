import re


s = '01-11-2018 12:12:12  an access error'
pattern = r'(\d\d-\d\d-\d{4})\ (\d\d:\d\d:\d\d)'  # grouping aka backref...


m = re.search(pattern, s, re.I)
print(m)
print()

if m:
    print('match string :', m.group())
    print('date :', m.group(1))
    print('time :', m.group(2))
    print(m.groups())
else:
    print('failed to match')

