import re

s = 'root:x:0:0:root:/root:/bin/bash'
pattern, repl = '[AEIOU]', '*'

counter = 0
match_count = len(re.findall(pattern, s, re.I))
print(match_count)


def replace_last_two(m):
    global counter
    counter += 1
    replacement = repl if counter > match_count - 2 else m.group()
    return replacement

s3 = re.sub(pattern, replace_last_two, s, flags=re.I)
print(s3)

