"""
PackageManager

name
version

__init__()
get_information()
"""
from pprint import pprint as pp

class PackageManager:
    """a demo class"""
    __name = None
    version = None

    def __init__(self, *args):
        """initializer to add attributes and initialize them"""
        if len(args) == 2:
            self.__name, self.version = args

    def __get_information(self):
        """getter methods"""
        print("name :", self.__name)
        print('version :', self.version)

    def wrapper(self):
        self.__get_information()


pm = PackageManager('cpan', '2.2.3')
pp(pm.__dict__)  # bucket where the attrib and values were stored
#pm._PackageManager__get_information()
# pm.wrapper()
#pp(dir(pm))
# print(pm.__name)
