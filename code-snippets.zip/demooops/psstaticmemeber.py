class MaxConnectionError(Exception):
    pass


class Connections:
    counter = 0         # static variables aka class variables
    max_connections = 5

    def __init__(self, conn_id):
        Connections.counter += 1
        self.conn_id = conn_id
        Connections.check4limit()

    def __str__(self):
        return "Connection id:{}".format(self.conn_id)

    @staticmethod
    def check4limit():
        if Connections.counter > Connections.max_connections:
            raise MaxConnectionError("reached the maximum number of connections")

    #print(check4limit)
    # check4limit = staticmethod(check4limit)
    #print(check4limit)
    #exit(1)


if __name__ == '__main__':
    c1 = Connections(123)
    c2 = Connections(212)
    print(c1.counter)
    print(c2.counter)
    print(Connections.counter)

    """try:
    
        for item in range(8):
            c = Connections(item)
            print(c)
    except MaxConnectionError as err:
        print(err)
    """

