import psperson


class Employee(psperson.Person):
    def __init__(self, eid, fname, lname):
        self.eid = eid
        # invoke overridden methods
        # super(Employee, self).__init__(fname, lname) # py 2.x
        super().__init__(fname, lname)   # py 3.x

    def get_info(self):
        print("employee id :", self.eid)
        #  super(Employee, self).get_info()   # py 2.7
        super().get_info()


if __name__ == '__main__':
    e = Employee('v4004', 'guido', 'rossum')
    e.get_info()
