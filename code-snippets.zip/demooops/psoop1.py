import os
import sys
import math


class Demo:
    pass


d = Demo()
print(d)
print(Demo)
print(__name__)
print(os.__name__)
print(sys.__name__)
print(math.__name__)
