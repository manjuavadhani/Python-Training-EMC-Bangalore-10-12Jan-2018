def demo():
    print('null argument function')

print(demo)

def demo(a, b):
    print(a + b)

print(demo)

demo = 'peter'
print(demo)