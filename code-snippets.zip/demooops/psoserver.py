from os import listdir
from os.path import getsize, getmtime, isfile, isdir, join
from pprint import pprint as pp
from time import ctime

dir_name = '/tmp'
# pp(listdir(dir_name))

abs_path = dir_name + '/' + '+~JF334000292936467027.tmp'
print(abs_path)
print()
abs_path = join(dir_name, '+~JF334000292936467027.tmp')
print(abs_path)

print(isfile(abs_path))
print(isdir(abs_path))
print()
print(getsize(abs_path))
print(getmtime(abs_path))
print(ctime(getmtime(abs_path)))