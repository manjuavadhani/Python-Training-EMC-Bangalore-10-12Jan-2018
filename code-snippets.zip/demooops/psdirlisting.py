from pprint import pprint as pp
from os import listdir
from os.path import getsize, getmtime, isfile, join, basename
from time import ctime


class DirectoryListing:
    directories = None
    container = dict()

    def __init__(self, *args):
        self.directories = args
        self.__read_directories()

    def __read_directories(self):
        for dir_name in self.directories:
            list_of_files = [join(dir_name, item) for item in listdir(dir_name)
                             if isfile(join(dir_name, item))]

            for file_name in list_of_files:
                file_prop = [getsize(file_name), ctime(getmtime(file_name))]
                file_name = basename(file_name)
                self.container.setdefault(dir_name, {})[file_name] = file_prop


if __name__ == '__main__':
    dl = DirectoryListing('/tmp', '/home/ravi')
    # pp(dl.container)


    for dir_name, dir_items in dl.container.items():
        for file_name, file_properties in dir_items.items():
            print(dir_name, end="\t")
            print(file_name, end="\t")

            for value in file_properties:
                print(value, end="\t")
            print()

"""
{
'd1': {
        'f1': [size, mtime],
        'f2': [size, mtime],...
    },
'd2': {
        'g1': [size, mtime],
        'g2': [size, mtime],...
    },......
    
}
"""
