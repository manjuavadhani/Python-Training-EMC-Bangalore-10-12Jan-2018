"""
PackageManager

name
version

__init__()
get_information()
"""


class PackageManager:
    """a demo class"""
    name = None
    version = None

    def __init__(self, *args):
        """initializer to add attributes and initialize them"""
        if len(args) == 2:
            self.name, self.version = args

    def get_information(self):
        """getter methods"""
        print("name :", self.name)
        print('version :', self.version)


pm = PackageManager()
pm.get_information()
print()
pm = PackageManager('cpan', '2.2.3')
pm.get_information()