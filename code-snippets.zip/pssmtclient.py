import smtplib
from sys import platform, version

from_addr = "ravi@localhost"
to_addr = "training@localhost"

subject = "python version"
message = "platform : {}\nversion : {}".format(platform, version)

mail_body = "From: {}\n".format(from_addr)
mail_body += "To: {}\n".format(to_addr)
mail_body += "Subject: {}\n\n\n".format(subject)
mail_body += message

smtp = smtplib.SMTP('mailhub.lss.emc.com')
smtp.sendmail(from_addr, to_addr, mail_body)
smtp.close()
