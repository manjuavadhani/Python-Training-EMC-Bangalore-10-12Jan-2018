from json import dumps

class tojson:
    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        dict_content = self.func(*args)
        return dumps(dict_content)


class logger:
    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        ret_value = self.func(*args)
        note = "{} args: {} return: {}".format(self.func.__name__,
                                               args, ret_value)

        print(note)
        return dict(result=ret_value)


def validator(f):
    def handler(*args, **kwargs):
        for arg in args:
            if type(arg) not in [int, float]:
                raise TypeError("invalid argument ")

        return f(*args)

    return handler

@validator
def compute(a, b):
    return a * b


#compute = logger(compute)
# print(compute)
print(compute(2, 3+3j))