from copy import deepcopy

items = dict(name='pip')  # shallow copy vs deep copy
print(id(items))

temp2 = items
temp3 = deepcopy(items)

print(id(temp2))
print(id(temp3))
temp3.popitem()
print(items)