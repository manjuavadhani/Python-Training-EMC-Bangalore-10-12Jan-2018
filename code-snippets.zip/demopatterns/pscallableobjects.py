class Demo:
    def __init__(self):
        self.dummy = 0.1

    def __call__(self, *args, **kwargs):
        return ">> {} <<".format(self.dummy)


d = Demo()
print(callable(d))
print(d())
