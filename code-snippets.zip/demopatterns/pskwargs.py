def tuner(*args, **kwargs):
    print(kwargs)
    print(args)


#demo()
#demo(1,2,3,4, reverse=True, backup='.bak')

#tuner(0.75, 0.87, 0.55)
tuner(constranst=0.75, hue=0.87, brightness=0.55)